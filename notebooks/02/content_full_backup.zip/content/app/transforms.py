"""
transforms.py

Pure data transformations only.

Responsibilities:
- Filter data by week
- Aggregate across years (if needed)
- Build site × week matrices
- Normalize values per week
- Compute ranks (optional)

NO visualization logic
NO thresholds
NO suitability rules
"""

import pandas as pd


# -----------------------------
# Filtering
# -----------------------------
def filter_weeks(
    df: pd.DataFrame,
    weeks: list[int] | None = None
) -> pd.DataFrame:
    """
    Filter dataframe to a subset of weeks.
    """
    if weeks is None:
        return df

    return df[df["week_bin"].isin(weeks)].copy()


# -----------------------------
# Aggregation
# -----------------------------
def aggregate_site_week(
    df: pd.DataFrame,
    value_col: str,
    agg: str = "mean"
) -> pd.DataFrame:
    """
    Aggregate values by site and week.

    Parameters
    ----------
    value_col : column to aggregate
    agg : aggregation method ("mean", "median", "max", etc.)
    """
    if value_col not in df.columns:
        raise ValueError(f"Column '{value_col}' not found")

    return (
        df
        .groupby(["site_name", "week_bin"], as_index=False)
        .agg({value_col: agg})
    )


# -----------------------------
# Matrix construction
# -----------------------------
def build_site_week_matrix(
    df: pd.DataFrame,
    value_col: str
) -> pd.DataFrame:
    """
    Pivot to site × week matrix.
    """
    if value_col not in df.columns:
        raise ValueError(f"Column '{value_col}' not found")

    matrix = df.pivot(
        index="site_name",
        columns="week_bin",
        values=value_col
    )

    return matrix.sort_index()


# -----------------------------
# Normalization
# -----------------------------
def normalize_per_week(
    matrix: pd.DataFrame,
    method: str = "minmax"
) -> pd.DataFrame:
    """
    Normalize values column-wise (per week).

    Methods:
    - minmax : scale to [0, 1]
    - zscore : standard score
    """
    if method == "minmax":
        return (matrix - matrix.min()) / (matrix.max() - matrix.min())

    if method == "zscore":
        return (matrix - matrix.mean()) / matrix.std()

    raise ValueError(f"Unknown normalization method '{method}'")


# -----------------------------
# Ranking
# -----------------------------
def rank_per_week(
    matrix: pd.DataFrame,
    ascending: bool = False
) -> pd.DataFrame:
    """
    Rank sites per week.

    ascending=False → best = rank 1
    """
    return matrix.rank(
        axis=0,
        method="min",
        ascending=ascending
    )
